class PID
{
public:
    PID();
    PID(const float kp, const float ki, const float kd);
    void setKi(const float ki);
    void setKp(const float kp);
    void setKd(const float kd);
    void setLimit(const float lower_limit, const float upper_limit);
    float computeOutput(const float target, const float value);
private:
    float _ki;
    float _kp;
    float _kd;
    float _integral;
    float _lastErr;
    float _error;
    float _uLim;
    float _lLim;
    float _pPart;
    float _iPart;
    float _dPart;
    float _output;
    float _antiWindErr;
};