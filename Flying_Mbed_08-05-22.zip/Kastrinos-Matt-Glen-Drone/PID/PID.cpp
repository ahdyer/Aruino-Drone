#include "PID.h"

PID::PID()
{
    _ki=0;
    _kp=0;
    _kd=0;
    _integral=0;
    _lastErr=0;
    _error=0;
    _uLim=0;
    _lLim=0;
    _pPart=0;
    _iPart=0;
    _dPart=0;
    _output=0;
    _antiWindErr=0;
}

PID::PID(const float kp, const float ki, const float kd)
{
    _kp = kp;
    _ki = ki;
    _kd = kd;
    
}

void PID::setKi(const float ki)
{
    _ki = ki;
}

void PID::setKp(const float kp)
{
    _kp = kp;
}

void PID::setKd(const float kd)
{
    _kd = kd;
}

void PID::setLimit(const float lower_limit, const float upper_limit)
{
    _uLim = upper_limit;
    _lLim = lower_limit;
}

float PID::computeOutput(const float target, const float value)
{
    _error = target - value;
    _pPart = _kp*_error;
    _iPart = _integral;
    _dPart = _kd*(_error-_lastErr);
    _lastErr = _error;
    _output = _pPart + _iPart + _dPart;
    _antiWindErr = ((_output > _uLim || _output < _lLim) && (_error * _output > 0)) ? 0 : _error;
    _integral = _ki*_antiWindErr;
    return _output;
}